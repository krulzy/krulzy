require("./global")

const mess = {
   wait: "`SABAR PEPEK LAGI PROSES`",
   success: "`DONE LER`",
   on: "`ANJAY ON", 
   off: "`ANJAY OFF`",
   query: {
       text: "`TEKSNYA MANA MEK?`",
       link: "`LINKNYA MANA LER?`",
   },
   error: {
       fitur: "`YAHAHA ERROR PERBAIKI SENDIRI SONO ANJING`",
   },
   only: {
       group: "`BISANYA DI DALEM GRUP KONTOL`",
       private: "`BISANYA DI PRIVATE CHAT ANJING`",
       owner: "`LU SIAPA NGENTOT LU BUKAN OWNER GWH`",
       admin: "`LU SIAPA MEMEK`",
       badmin: "`Bot Harus Jadi Admin Group Ya Tolol`",
       premium: "`SO ASIK KONTOL`",
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})