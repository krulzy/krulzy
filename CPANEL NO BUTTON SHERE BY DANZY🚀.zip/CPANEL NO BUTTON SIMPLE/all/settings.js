require("./module")

//═══════OWNER SETTING═══════\\

global.owner = "6283895883216" //PAKE NO LU BIAR BISA ADD AKSES
global.namabot = "FVCK-BOTZZ🚀" //NAMA BOT GANTI
global.namaCreator = "SWIPER FVCK 🜲" //NAMA CREATOR GANTI AJA
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = false //NOT CHANGE / JANGAN GANTI
global.versisc = '9.9.9' //NOT CHANGE / JANGAN GANTI
global.isLink = 'https://whatsapp.com/channel/0029VaqVHdI7dmeWCIdOT61q' // GANTI PAKE LINK CH/GB LU
global.simbol = '🜲' //GANTI AJA BEBAS

//═══════PANEL SETTING═══════\\

global.domain = 'https://pubjaizxswip.tekaruka.my.id' //ISI DOMAIN PANEL LU
global.apikey = 'ptla_AS2sKwlTm1PJeb14uRmCbnnG9vhZMMmDCAMBpsDJcjE' //ISI APIKEY PLTA LU KALO G TAU LIAT YT 
global.capikey = 'ptlc_KkrIUeUNNzIvEUQeHRT6tcwW2DGUjp9xFabn2uPBt3d' //ISI APIKEY PLTC MU KALO G TAU LIAT YT 
global.eggsnya = '15' //PAKE ID EGGS MU KALO GA TAU DEFAULT AJA
global.location = '1' //JANGAN DIGANTI KALO G MAU EROR

//═══════IMAGE SETTING═══════\\

global.imageurl = 'https://files.catbox.moe/j1d0d7.jpg' //GANTI PP YANG UDAH DI CONVERT MENJADI LINK
global.thumb = fs.readFileSync("./thumb.png") //NOT CHANGE / JANGAN GANTI

//═══════PUSH KONTAK SETTING═══════\\

global.tekspushkon = "" //NOT CHANGE / JANGAN GANTI
global.tekspushkonv2 = "" //NOT CHANGE / JANGAN GANTI

//═══════GLOBAL SETTING═══════\\

global.packname = "𝐅𝐕𝐂𝐊🜲" //GANTI AJ
global.author = "𝐒𝐖𝐈𝐏𝐄𝐑 𝐅𝐕𝐂𝐊🜲" //GANTI SERAH MU
global.jumlah = "5" //NOT CHANGE / JANGAN GANTI

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})